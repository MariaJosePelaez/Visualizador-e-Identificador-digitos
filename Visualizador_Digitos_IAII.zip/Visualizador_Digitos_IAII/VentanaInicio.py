__author__ = "Pedro Bermeo, María José Peláez"
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Pedro Bermeo, María José Peláez"
__email__ = "pbermeo@ups.edu.ec, mpelaezc@est.ups.edu.ec"
__status__ = "Inteligencia Artificial"

from PrediccionRed import PrediccionRed
from tkinter import *
from tkinter import ttk
import tkinter.messagebox as msg
import numpy as np
from Utilities import Utilities

class VentanaInicio(Frame):

	def __init__(self, master = None):
		super().__init__(root)
		self.master = master
		self.redN = PrediccionRed(946, 1000)
		self.coordenadas = []
		self.indices = self.redN.obtenerIndices()
		self.utilities = Utilities()
		self.inicializer()

	def inicializer(self):
		self.master.title("Visualizador e Identificador de Números")
		self.master.configure(bg='#3E4149')
		self.master.resizable(0, 0)
		self.grid(row = 0,column = 0)
		self.crearMatriz()
		
		btnEntrenamiento = Button(self, text="Entrenamiento", height=2, bg='peachpuff', highlightbackground='#3E4149', command=self.entrenar)
		btnEntrenamiento.grid(columnspan = 11, sticky = W + E + N + S,row = 33, column = 0)
		
		btnNuevo = Button(self, text="Nuevo", height=2, bg='olive', highlightbackground='#3E4149', command=self.renovar)
		btnNuevo.grid(columnspan = 10, sticky = W + E + N + S,row = 33, column = 11)

		btnDibujar = Button(self, text="Dibujar Numero", height=2, bg='peachpuff', highlightbackground='#3E4149', command=self.predecir)
		btnDibujar.grid(columnspan = 11, sticky = W + E + N + S,row = 33, column = 21)

		lblText = ttk.Label(self.master, text='Digitos')
		lblText.grid(row=3, column=3)

		self.cbxData = ttk.Combobox(self, values = [str(i) for i in self.indices])
		self.cbxData.grid(columnspan = 11, row = 32, column = 11)
		self.cbxData.bind('<<ComboboxSelected>>', self.cargaDatos)
		

	def entrenar(self):
		self.redN.obtenerEntrenamiento()

	def predecir(self):
		matriz = self.generarMatriz(32, self.coordenadas)
		numero = np.ravel(np.matrix(matriz))
		prediccion = self.redN.obtenerPrediccion(numero)
		msg.showinfo("Resultado", "El Numero que usted dibujo es: " + str(prediccion))
		#for i in range(len(matriz)):
		#	print(matriz[i])

	def crearMatriz(self):
		self.btn = [[0 for x in range(32)] for x in range(32)] 
		for x in range(32):
			for y in range(32):
				self.btn[x][y] = Button(self, bg='darksalmon', command=lambda x1=x, y1=y: self.seleccionar(x1,y1))
				self.btn[x][y].grid(column = x, row = y)

	def generarMatriz(self, n, coordenadas):
		matriz = []
		for i in range(n):
			matriz.append([0 for j in range(n)])

		for i in range(len(coordenadas)):
			x, y = coordenadas[i]
			matriz[y][x] = 1
		return matriz

	def seleccionar(self, x, y):
		self.btn[x][y].config(bg = "lime")
		self.coordenadas.append((x, y))
		
	def renovar(self):
		self.crearMatriz()
		self.coordenadas = []
		
	def cargaDatos(self, evt):
		self.renovar()
		_id = [int(i) for i in (str(self.cbxData.get()).replace(')','').replace(' ','').replace('(','')).split(',')]
		
		data = self.utilities.get_digit(_id[1],_id[2])
		for i in range(len(data)):
			for j in range(len(data[i])):
				if(data[i][j] == 1):
					self.seleccionar(j, i)
			

if __name__ == '__main__':
	root = Tk()
	ventana = VentanaInicio(root)
	root.mainloop()
