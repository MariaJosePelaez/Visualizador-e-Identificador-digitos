<p align="center">
   <img src="img/logo.png">
</p>

# Identificador de Dígitos I.A2

### Proyecto Interciclo
**Alumnos:** Frank Montalvo Ochoa , Damián Gutiérrez<br/>
